// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "LinkedListPatientQueue.h"

LinkedListPatientQueue::LinkedListPatientQueue() {
    // TODO: write this constructor
}

LinkedListPatientQueue::~LinkedListPatientQueue() {
    // TODO: write this destructor
}

void LinkedListPatientQueue::clear() {
    // TODO: write this function
}

string LinkedListPatientQueue::frontName() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

int LinkedListPatientQueue::frontPriority() {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}

bool LinkedListPatientQueue::isEmpty() {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

void LinkedListPatientQueue::newPatient(string name, int priority) {
    // TODO: write this function
}

string LinkedListPatientQueue::processPatient() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

void LinkedListPatientQueue::upgradePatient(string name, int newPriority) {
    // TODO: write this function
}

ostream& operator <<(ostream& out, const LinkedListPatientQueue& queue) {
    // TODO: write this function
    return out;
}
