// This is the H file you will edit and turn in. (TODO: Remove this comment!)

#pragma once

#include <iostream>
#include <string>
#include "patientnode.h"
using namespace std;

class PatientQueue {
public:
    PatientQueue() {}
    ~PatientQueue() {}
    void clear() {}
    virtual string frontName() {return ""; }
    virtual int frontPriority() {return 0;}
    virtual bool isEmpty() {return false;}
    virtual void newPatient(string name, int priority) {}
    virtual string processPatient() {return "";}
    virtual void upgradePatient(string name, int newPriority) {}


private:
    friend ostream& operator <<(ostream& out, const PatientQueue& queue) {return out;}
};

/*
 */
ostream& operator <<(ostream& out, const PatientQueue& queue);

